<?php
//获取传入的参数
$u=$_GET['username'];
//连接数据库
$link=mysqli_connect("localhost",'root','','bbb');
//设置编码
mysqli_set_charset($link,"utf8");
//SQL语句
$sql="select * from user1 where name='$u'";
//执行SQL
$result=mysqli_query($link,$sql);
//判断是否执行成功
if($row=mysqli_fetch_assoc($result)){
    echo "1";
}else{
    echo "0";
}
//关闭数据库连接
mysqli_close($link);
?>