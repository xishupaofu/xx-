<?php
//获取客户端传递的参数
$id=$_GET['uid'];

//连接数据库
$link=mysqli_connect("localhost",'root','','bbb');
//设置编码
mysqli_set_charset($link,"utf8");
//把传入的参数，书写在SQL语句中
$sql="select * from goods where goods_id=$id";
//执行SQL语句，并返回结果集
$result=mysqli_query($link,$sql);
//获取结果集中的第一条数据
$row=mysqli_fetch_assoc($result);
//把数组进行编码，并转为字符串返回响应结果
echo json_encode($row);
//关闭数据库连接
mysqli_close($link);
?>