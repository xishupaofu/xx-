<?php
//连接数据库
$link=mysqli_connect("localhost",'root','','bbb');
//设置编码
mysqli_set_charset($link,"utf8");
//把传入的参数，书写在SQL语句中
$sql="select * from goods order by goods_id desc limit 0,5";
//执行SQL语句，并返回结果集
$result=mysqli_query($link,$sql);
//创建数组，保存所有数据
$ar1=[];
//遍历结果集中的每条信息
while($row=mysqli_fetch_assoc($result)){
    //把遍历出来的数据追加到数组中
    array_push($ar1,$row);
}
//把数组进行编码，并转为字符串返回响应结果
echo json_encode($ar1);
//关闭数据库连接
mysqli_close($link);

?>