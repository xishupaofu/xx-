<?php
//获取传入的参数
$u=$_GET['user'];
$p=$_GET['pass'];
$tel=$_GET['phone'];
$e=$_GET['email'];

//连接数据库
$link=mysqli_connect("localhost",'root','','bbb');
//设置编码
mysqli_set_charset($link,"utf8");
//SQL语句
$sql="insert into user1(name,pass,phone,email) values('$u','$p','$tel','$e')";
//执行SQL
$result=mysqli_query($link,$sql);
//判断是否执行成功
if($result){
    echo "1";
}else{
    echo "0";
}
//关闭数据库连接
mysqli_close($link);

?>