<?php
//获取传入的页码
$m=$_GET['num'];
//连接数据库
$link=mysqli_connect("localhost",'root','','bbb');
//设置编码
mysqli_set_charset($link,"utf8");
//计算获取数据的开始下标
$mm=($m-1)*20;
//SQL语句
$sql="select * from goods limit $mm,20";
//执行SQL语句，并返回结果集
$result=mysqli_query($link,$sql);
//创建数组，存放结果集中所有数据
$ar1=[];
//遍历结果集中每条数据
while($row=mysqli_fetch_assoc($result)){
    //把遍历出来的数据追加到数组中
    array_push($ar1,$row);
}
//把当前数组进行编码，并转为字符串返回响应结果
echo json_encode($ar1);
//关闭数据库连接
mysqli_close($link);
?>