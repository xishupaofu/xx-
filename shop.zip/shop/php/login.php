<?php
//获取客户端传入的参数
$u=$_POST['user'];
$p=$_POST['pass'];

//连接数据库
$link=mysqli_connect("localhost",'root','','bbb');
//设置编码
mysqli_set_charset($link,"utf8");
//把传入的参数，书写在SQL语句中
$sql="select * from user1 where name='$u' and pass='$p'";
//执行SQL语句，并返回结果集
$result=mysqli_query($link,$sql);
//判断结果集中是否有数据
if($row=mysqli_fetch_row($result)){
    echo "1";
}else{
    echo "0";
}
//关闭数据库连接
mysqli_close($link);

?>