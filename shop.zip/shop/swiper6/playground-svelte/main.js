// eslint-disable-next-line
import '../build/swiper-bundle.css';

import App from './App.svelte';

// eslint-disable-next-line
new App({
  // eslint-disable-next-line
  target: document.getElementById('app'),
});
