import addClasses from './addClasses';
import removeClasses from './removeClasses';

export default { addClasses, removeClasses };
