//获取操作对象
var box=document.querySelector('.xq-content-con')
//获取地址栏中的参数
var search=location.search
//获取的内容
var o1;
console.log('1')
//判断地址栏中是否有参数
if(search){
    //获取id的值
    var id=search.split('=')[1]
    //把当前id通过ajax传递到服务器中，获取对应的数据
    ajax1({
        url:'../php/xiangqing.php',
        data:`uid=${id}`,
        success:function(dt){
            //把字符串转为对象
            o1=eval('('+dt+')')
            //创建字符串，拼接所有内容
            var str=`
            <div class="xq-content-con-left">
                <div class="xq-content-con-left-box">
                    <img src="${o1.goods_big_logo}" alt="">
                    <div class="xq-content-con-left-mark"></div>
                </div>
                <div class="xq-content-con-right-box">
                    <img src="${o1.goods_big_logo}" alt="">
                </div>
                <ul class="xq-content-con-left-imgs">
                    <li class="bd">
                        <img src="${o1.goods_small_logo}">
                    </li>
                    <li>
                        <img src="../image/bg2.png">
                    </li>
                    <li>
                        <img src="../image/bg3.png">
                    </li>
                    <li>
                        <img src="../image/bg4.png">
                    </li>
                    <li>
                        <img src="../image/bg5.png">
                    </li>
                </ul>
            </div>
            <div class="xq-content-con-middle">
                <h4>${o1.goods_name}</h4>
                <p class="p1">【家电清凉节-盛夏狂欢】【到手价不高于899元】 【金属全面屏，极窄边框超高屏占比，大功率立体声影院级扬声器】 【更多好货点击查看></p>
                <div class="price">
                    京 东 价 <span>￥ ${o1.goods_price}</span> 降价通知
                </div>
                <p>配 送 至:广东湛江市赤坎区北桥街道 有货</p>
                <div class="border"></div>
                <div class="left">
                    选择尺寸：
                </div>
                <div class="right">
                    <div>
                        <img src="../image/bg1.png">【55英寸】Redmi A55 2022款
                    </div>
                    <div>
                        <img src="../image/bg2.png">【55英寸】Redmi A55 2022款
                    </div>
                    <div>
                        <img src="../image/bg3.png">【55英寸】Redmi A55 2022款
                    </div>
                    <div>
                        <img src="../image/bg4.png">【55英寸】Redmi A55 2022款
                    </div>
                    <div>
                        <img src="../image/bg5.png">【55英寸】Redmi A55 2022款
                    </div>
                    <div>
                        <img src="../image/bg1.png">【55英寸】Redmi A55 2022款
                    </div>
                    <div>
                        <img src="../image/bg1.png">【55英寸】Redmi A55 2022款
                    </div>
                    <div>
                        <img src="../image/bg1.png">【55英寸】Redmi A55 2022款
                    </div>
                    <p class="clear"></p>
                    <div class="div-num">
                        <button>-</button><input type="text" value="1"><button>+</button>
                        <button class="btn">加入购物车</button>
                    </div>
                </div>
                <p class="clear"></p>
            </div>
            <div class="xq-content-con-right">
                <ul>
                    <li>
                        <img src="../image/bg1.png" width="130" height="130">
                        <p>Redmi K40游戏增强版 天玑1200旗舰处理器 67W闪充 120Hz高刷</p>
                        <p>￥<span>1699.00</span></p>
                    </li>
                    <li>
                        <img src="../image/bg2.png" width="130" height="130">
                        <p>Redmi K40游戏增强版 天玑1200旗舰处理器 67W闪充 120Hz高刷</p>
                        <p>￥<span>2699.00</span></p>
                    </li>
                </ul>
            </div>
            <p class="clear"></p>
            <div class="tab">
                <ul>
                    <li data-index='0' class="bg">商品介绍</li>
                    <li data-index='1'>规格与包装</li>
                    <li data-index='2'>售后保障</li>
                    <li data-index='3'>预约说明</li>
                    <p class="clear"></p>
                </ul>
            </div>
            <div class="tab-p">
                <div class='div show'>${o1.goods_introduce}</div>
                <div class='div'>
                <p>包装尺寸:</p>   深716mm；宽980mm；高1888mm
                <p>产品重量</p>    85kg
                <p>产品尺寸</p>   深647mm；宽908mm；高1775mm
                </div>
                <div class='div'>
                <p>厂家服务</p>
                <p>本商品质保周期为1年质保，在此时间范围内可提交维修申请，具体请以厂家服务为准。 本产品提供上门安装调试、提供上门检测和维修等售后服务，自收到商品之日起，如您所购买家电商品出现质量问题，请先联系厂家进行检测，凭厂商提供的故障检测证明，在“我的京东-客户服务-返修退换货”页面提交退换申请，将有专业售后人员提供服务。京东承诺您：30天内产品出现质量问题可退货，180天内产品出现质量问题可换货，超过180天按国家三包规定享受服务。
                您可以查询本品牌在各地售后服务中心的联系方式，请点击这儿查询......</p>
                <p>品牌官方网站：http://www.haier.com/cn/</p>
                <p> 售后服务电话：4006-999-999</p>
                </div>
                <div class='div'>
                预约规则：
                <p>1、部分商品预约成功后才有抢购资格，预约成功后，请关注抢购时间及时抢购，货源有限，先抢先得！</p> 
                <p>2、部分商品在预约期间抢购时间未定，我们会在商品开抢前通过Push通知提醒您，请在设置中选择允许通知，以免错过抢购时间。</p>
                <p>3、对于预约成功享优惠的商品，预约用户可获得优惠券或专属优惠。优惠券在抢购开始后使用，使用时间以优惠券有效期为准；专属优惠在抢购开始后，点击“立即抢购”将商品加入购物车，可在购物车查看优惠，若抢购时间结束，优惠自动失效。</p>
                <p>4、查看预约商品请至“我的京东”-“我的活动”-“我的预约”进行查看。</p>
                </div>
            </div> 
            `
            //把当前拼接好的内容渲染到页面中
            box.innerHTML=str
            
            //放大镜
            //获取操作对象
            var leftBox=document.querySelector('.xq-content-con-left-box')
            var mark=leftBox.querySelector('.xq-content-con-left-mark')
            var rightBox=document.querySelector('.xq-content-con-right-box')
            var rightImg=rightBox.querySelector('img')

            //给左边大盒子对象绑定鼠标移入，移出，移动事件
            leftBox.onmouseover=function(){
                mark.style.display='block'
                rightBox.style.display='block'
            }
            leftBox.onmouseout=function(){
                mark.style.display='none'
                rightBox.style.display='none'
            }
            leftBox.onmousemove=function(e){
                //事件对象兼容
                var e = e || window.event
                //获取当前蒙版层的移动距离
                var left1=e.pageX-leftBox.offsetLeft-parseInt(mark.offsetWidth/2)
                var top1=e.pageY-leftBox.offsetTop-parseInt(mark.offsetHeight/2)
                //移动最大值
                var maxX=leftBox.offsetWidth-mark.offsetWidth
                var maxY=leftBox.offsetHeight-mark.offsetHeight
                //右边图片进行移动
                var imgX,imgY
                //设置蒙版层的边界
                if(left1<=0){
                    mark.style.left='0px'
                    imgX=0
                }else if(left1>=maxX){
                    mark.style.left=maxX+'px'
                    imgX=maxX
                }else{
                    mark.style.left=left1+'px'
                    imgX=left1
                }

                if(top1<=0){
                    mark.style.top='0px'
                    imgY=0
                }else if(top1>=maxY){
                    mark.style.top=maxY+'px'
                    imgY=maxY
                }else{
                    mark.style.top=top1+'px'
                    imgY=top1
                }
                
                //让右边图片进行移动
                rightImg.style.left=-2*imgX+'px'
                rightImg.style.top=-2*imgY+'px'


            }
        }
    })
}else{
    alert("不能非法进入")
    location='./list.html'
}

//给大盒子对象绑定点击事件
box.onclick=function(e){
    //事件对象兼容
    var e = e || window.event
    var trg=e.target
    //判断点击是否为+
    if(trg.innerHTML=="+"){
        //获取上一个兄弟元素
        var num=trg.previousElementSibling.value
        //修改数量
        num++
        //重新给输入框赋值
        trg.previousElementSibling.value=num
    }
    //判断点击是否为-
    if(trg.innerHTML=="-"){
        var num=trg.nextElementSibling.value
        if(num>1){
            num--
        }else{
            num=1
        }
        //给输入框重新赋值
        trg.nextElementSibling.value=num
    }
    //判断点击的是否为"加入购物车"
    if(trg.innerHTML=="加入购物车"){
        //获取cookie中的账号
        var name1=getCookie('name1')
        //获取输入框中的数量
        var mm=document.querySelector('[type="text"]').value
        //判断该账号是否存在
        if(name1){
            //获取localStorage中的值
            var ar1=localStorage.getItem(name1) ||"[]"
            //把字符串转为数组对象
            ar1=eval('('+ar1+')')
            //判断当前数组对象长度是否大于0
            if(ar1.length>0){
                //创建变量，验证数组中的商品是否等于当前添加的商品
                var bool=false
                //遍历数组中的商品元素
                ar1.forEach(item=>{
                    //判断当前遍历的商品id是否等于o1对象中的id
                    if(item.goods_id==o1.goods_id){
                        bool=true
                        //修改当前商品的数量
                        item.cart_number=parseInt(item.cart_number)+parseInt(mm)
                    }
                })
                //判断bool是否为true
                if(bool){
                    //再把该数组存放在localStorage中
                    localStorage.setItem(name1,JSON.stringify(ar1))
                }else{
                    //修改商品的购买数量
                    o1.cart_number=mm
                    //直接把当前商品对象追加到数组中
                    ar1.push(o1)
                    //再把该数组存放在localStorage中
                    localStorage.setItem(name1,JSON.stringify(ar1))
                }
            }else{
                //修改商品的购买数量
                o1.cart_number=mm
                //直接把当前商品对象追加到数组中
                ar1.push(o1)
                //再把该数组存放在localStorage中
                localStorage.setItem(name1,JSON.stringify(ar1))
            }
        }else{
            alert("你还未登录")
            //获取当前地址栏中的地址
            var url1=location.href
            //跳转到登录页
            location=`./login.html?url=${url1}`
        }
    }
    //再次判断当前是否点击的为li对象
    if(trg.nodeName=="LI"){
       //获取当前li对象的下标
       var id=trg.getAttribute("data-index")
       //获取当前li的父节点中所有的子li对象
       var lis=trg.parentNode.children
       //获取li所对应的div对象
       var divs=document.querySelectorAll('.tab-p>div')
       //清除li对象中的class属性值bg和div对象中的class属性值show
       for(var i=0;i<divs.length;i++){
            lis[i].className=''
            divs[i].className='div'
       }
       //给指定的li和div对象添加相应的class属性值
       lis[id].className='bg'
       divs[id].className='div show'
    }
}