var dingdan=document.querySelector('.dingdan');
console.log(dingdan)
dingdan.onclick=function(){
    console.log(dingdan)
    var name1value=getCookie(name1);
    if(name1value){
        location='./cart.html'
    }else{
        location='./index.html'
    }
}