 
 //获取cookie中的账号
 var name1=getCookie('name1')
 //获取输入框中的数量
 var mm=document.querySelector('[type="text"]').value
 var goods = document.querySelector('.goods')
 //判断该账号是否存在
 if(name1){
     //获取localStorage中的值
     var ar1=localStorage.getItem(name1) ||"[]"
     //把字符串转为数组对象
     ar1=eval('('+ar1+')')
     var str=''
     //遍历数组中所有元素
     ar1.forEach(item=>{
        
        var prices = item.cart_number*item.goods_price
         str+=`
         <ul>
            <li>
                        <input type="checkbox" name="xuan">
                    </li>
                    <li>
                        <img src="${item.goods_big_logo}" alt="">
                    </li>
                    <li class="content">${item.goods_name}</li>
                    <li>
                        <button>-</button>
                        <input type="text" value="${item.cart_number}" class="num1">
                        <button>+</button>
                    </li>
                    <li>
                        ￥<span>${item.goods_price}</span>
                    </li>
                    <li>￥<span>${prices}</span></li>
                    <li><button class="btn">删除</button></li>
            </ul>
         `
     })
     //把拼接好的内容渲染到页面中
    goods.innerHTML=str
 }
