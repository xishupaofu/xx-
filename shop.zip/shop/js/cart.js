/* 
            购物车的需求分析：
                1、页面布局
                2、功能分析：
                    1、全选
                    2、全删
                    3、数量的加减
                    4、删除指定商品
                    5、添加商品
                    6、统计购物车中所有商品总计
                    7、统计购物车中所有被选中的商品总计
                3、确定操作对象，以及事件类型
        */
//获取操作对象
var box = document.querySelector('.box')
// var xuans = document.querySelectorAll('[name="xuan"]')
var xuans = document.getElementsByName('xuan')
var content = document.querySelector('.content')
var quan = document.querySelector('[name="quan"]')
// var floor=document.querySelector(".box-floor")
var sum_price = document.querySelector(".sum-price")
var checked_num = document.querySelector(".num")
var goods_num = document.querySelector('[type="text"]')
//创建数组存放所有商品名称
// var ar1 = ['数码相机', '索尼相机', '华为相机', '单反相机', '苹果相机', '迦南相机', '佳能相机', '尼康相机']
// var m = 2 //图片名称
//给当前box对象绑定点击事件
box.onclick = function (e) {
    //兼容事件对象
    var e = e || window.event
    //获取操作目标（当前点击的对象）
    var trg = e.target
    //加法
    if (trg.innerHTML == "+") {
        //获取加法前面输入框的值
        var num = trg.previousElementSibling.value
        num++
        //重新把计算结果赋值给输入框
        trg.previousElementSibling.value = num
        //获取当前商品中所有的li对象
        var lis = trg.parentNode.parentNode.children
        //获取单价
        // var price=trg.parentNode.nextElementSibling.firstElementChild.innerHTML
        var price = lis[4].firstElementChild.innerHTML
        //计算小计
        var sum = num * price
        //把计算结果赋值给小计的位置
        lis[5].firstElementChild.innerHTML = sum.toFixed(2)
        checked_num.innerHTML = num
        check1()
        total1()
        total2()
    }
    //减法
    if (trg.innerHTML == "-") {
        //获取当前按钮下一个兄弟元素
        var num = trg.nextElementSibling.value
        //判断当前值是否大于1
        if (num > 1) {
            num--
        } else {
            num = 1
        }
        //重新把结果赋值给输入框
        trg.nextElementSibling.value = num

        //获取当前商品中所有的li对象
        var lis = trg.parentNode.parentNode.children
        //获取单价
        var price = lis[4].firstElementChild.innerHTML
        //计算小计
        var sum = num * price
        //把计算结果赋值给小计的位置
        lis[5].firstElementChild.innerHTML = sum.toFixed(2)
        check1()
        total1()
        total2()
    }
    //删除
    if (trg.innerHTML == "删除") {
        trg.parentNode.parentNode.remove()
        check1()
        total1()
        total2()
    }
    //全选
    if (trg.name == "quan") {
        //遍历每个选中框对象
        for (let i = 0; i < xuans.length; i++) {
            //判断当前全选框是否被选中
            if (trg.checked == true) {
                xuans[i].checked = true
            } else {
                xuans[i].checked = false
            }
        }
        total2()
    }
    //全删
    if (trg.innerHTML == "删除选中的商品") {
        //遍历选中框对象
        for (let i = 0; i < xuans.length; i++) {
            //判断当前选中框对象是否被选中
            if (xuans[i].checked) {
                //删除当前被选中的商品
                xuans[i].parentNode.parentElement.remove()
                i--
            }
        }
        check1()
        total1()
        total2()
    }
    // 判断是否选中
    if (trg.name == "xuan") {
        //遍历每个选中框对象
        for (let i = 0; i < xuans.length; i++) {
            //判断当前全选框是否被选中
            if (xuans[i].checked) {
                total1()
                total2()
            } 
            // else {
            //     xuans[i].checked = false
            // }
        }
        
    }

    //选中框函数
    function check1() {
        var mm = 0 //被选中的次数
        //遍历所有选中框对象
        for (let i = 0; i < xuans.length; i++) {
            //判断当前选中框是否被选中
            if (xuans[i].checked) {
                mm++
            }
        }
        //判断当前被选中的次数是否等于选中框的长度
        if (mm == xuans.length) {
            quan.checked = true
        } else {
            quan.checked = false
        }
        //当所有商品都被删除以后，全选框也不被选中
        if (xuans.length == 0) {
            quan.checked = false
        }
    }

}
total1()
//商品数量合计
function total1() {
    var num = 0 //总计
    // console.log(lis, 234);
    //遍历所有选中框对象
    var inps = document.querySelectorAll('.num1')
    for (let i = 0; i < xuans.length; i++) {
        if (xuans[i].checked) {

            //获取当前商品中的所有lis
            var lis = xuans[i].parentNode.parentNode.children
            //获取当前商品的数量s
            num += parseInt(inps[i].value)         
            //累加所有商品的小计
            // sum+=parseFloat(xiaoji)
        }
    }
    //把计算结果赋值给指定位置
    // floor.children[5].innerHTML=sum
    // sum_price.innerHTML=sum
    checked_num.innerHTML = num
}
total2()
//所选商品总计
function total2() {
    var sum = 0 //总计
    var num1 = 0  // 被选中的商品数量
    //遍历所有选中框对象
    for (let i = 0; i < xuans.length; i++) {
        //判断当前商品是否被选中
        if (xuans[i].checked) {
            // num1++
            //获取当前商品中的所有lis
            var lis = xuans[i].parentNode.parentNode.children
            //获取当前商品的小计
            var xiaoji = lis[5].firstElementChild.innerHTML
            //累加所有商品的小计
            sum += parseFloat(xiaoji)
        }
    }
    //把计算结果赋值给指定位置
    // floor.children[5].innerHTML=sum
    sum_price.innerHTML = sum
    // checked_num.innerHTML=num1
}
