//获取操作对象
var leftBox=document.querySelector('.content-left')
var rightBox=document.querySelector(".content-right")
var pags=document.querySelector('.pagination')
//获取左边盒子中列表对象
var leftUl=leftBox.querySelector('ul')
//获取右边盒子中的列表对象
var rightUl=rightBox.querySelector('.shop')
showLeft()
//获取数据库中的数据显示在页面中
function showLeft(){
    ajax1({
        url:'../php/list1.php',
        success:function(dt){
            //把字符串转为数组对象
            var ar1=eval('('+dt+')')
            //创建字符串拼接所有内容
            var str=''
            //遍历数组中所有元素
            ar1.forEach(item=>{
                str+=`
                <li>
                    <img src="${item.goods_small_logo}" alt="">
                    <p class="price">￥<span>${item.goods_price}</span></p>
                    <p><a href="./xiangqing.html?id=${item.goods_id}">${item.goods_name}</p>
                </li>
                `
            })
            //把拼接好的内容渲染到页面中
            leftUl.innerHTML=str
        }
    })
}

// showRight()
//创建函数显示右边内容
function showRight(){
    ajax1({
        url:'../php/list2.php',
        success:function(dt){
           //把字符串转为数组对象
           var ar1=eval('('+dt+')')
           //创建对象，配置分页器参数信息
           var o1={
            //分页页码信息
                pageInfo:{
                    pagenum:1,
                    pagesize:20,
                    totalsize:ar1.length,
                    totalpage:Math.ceil(ar1.length/20)
                },
                //文本信息
                textInfo:{
                    first:"首页",
                    prev:"上一页",
                    next:"下一页",
                    last:"尾页"
                } ,
                change(m){
                    //根据当前页码从数组中获取当前页要显示的数据
                    var ar2=ar1.slice((m-1)*20,m*20)
                    //创建字符串，拼接所有内容
                    var str=''
                    //遍历数组中所有元素
                    ar2.forEach(item=>{
                        str+=`
                        <li>
                            <img src="${item.goods_small_logo}" width="220" heigth="220">
                            <p class="price">￥<span>${item.goods_price}</span></p>
                            <p class="title">${item.goods_name}</p>
                            <p>100万+条评价</p>
                            <p>小米京东自营旗舰店</p>
                            <ol>
                                <li>对比</li>
                                <li>关注</li>
                                <li>加入购物车</li>
                            </ol>
                        </li>
                        `
                    })
                    //拼接ul最后一部分内容
                    str+=`
                    <div class="clear"></div>
                    `
                    //把拼接好的内容渲染到页面中
                    rightUl.innerHTML=str
                }
           }
           //实例化分页器对象
           new Pagination(pags,o1)
        }
    })
}

showRight2()
//显示右边盒子中的数据
function showRight2(){
    //创建分页参数对象
    var o1={
        pageInfo:{
            pagenum:1,//当前第几页
            pagesize:20,//每页显示多少条
            totalsize:922,//总条数
            totalpage:Math.ceil(922/20)
        },
        textInfo:{
            first:'首页',
            prev:"上一页",
            next:"下一页",
            last:"尾页"
        },change(m){
            //根据页码去数据库中获取对应的数据
            ajax1({
                url:'../php/list3.php',
                // data:'num='+m
                data:`num=${m}`,
                success:function(dt){
                    //转为数组对象
                    var ar1=eval('('+dt+')')
                    //创建字符串，拼接所有内容
                    var str=''
                    //遍历数组中所有元素
                    ar1.forEach(item=>{
                        str+=`
                        <li>
                            <a href="./xiangqing.html?id=${item.goods_id}"><img src="${item.goods_small_logo}" width="220" heigth="220"></a>
                            <p class="price">￥<span>${item.goods_price}</span></p>
                            <p class="title">${item.goods_name}</p>
                            <p>100万+条评价</p>
                            <p>小米京东自营旗舰店</p>
                            <ol>
                                <li>对比</li>
                                <li>关注</li>
                                <li>加入购物车</li>
                            </ol>
                        </li>
                        `
                    })
                    //拼接ul最后一部分内容
                    str+=`
                    <div class="clear"></div>
                    `
                    //把拼接好的内容渲染到页面中
                    rightUl.innerHTML=str
                }
            })
        }
    }
    //实例化分页器对象
    new Pagination(pags,o1)
}