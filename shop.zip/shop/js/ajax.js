//封装ajax对象
function ajax1(o1){
    //创建一个默认参数
    var defObj={
        url:'',//请求地址
        type:'get',//请求方式
        data:'',//请求参数
        async:true,//是否异步
        success:function(){},//成功的回调函数
        error:function(){}//失败的回调函数
    }
    //判断传入的参数中是否有请求地址
    if(!o1.url){
        throw new Error("地址异常")
    }
    //使用传入的参数去替换默认参数
    //遍历传入实参对象
    for(var key in o1){
        //使用实参的值去替换默认参数中的值
        defObj[key]=o1[key]
    }
    //创建ajax对象
    var xhr=new XMLHttpRequest()
    //判断当前请求参数中是否有值
    if(defObj.data){
        //判断当前是否为get请求
        if(defObj.type.toLowerCase()=="get"){
            //配置请求信息
            xhr.open(defObj.type,defObj.url+'?'+defObj.data,defObj.async)
            //发送请求
            xhr.send()
        }else{
            //配置请求信息
            xhr.open(defObj.type,defObj.url,defObj.async)
            //设置请求头信息
            xhr.setRequestHeader('content-type','application/x-www-form-urlencoded')
            //发送请求
            xhr.send(defObj.data)
        }
    }else{
        //配置请求信息
        xhr.open(defObj.type,defObj.url,defObj.async)
        //发送请求
        xhr.send()
    }

    //监听ajax状态
    xhr.onreadystatechange=function(){
        //判断ajax状态是否结束
        if(xhr.readyState==4){
            //判断http请求是否成功
            if(xhr.status==200){
                //获取响应结果
                var txt=xhr.responseText
                //把获取到的响应结果作为实参，调用成功的回调函数
                defObj.success(txt)
            }else{
                defObj.error(xhr.status)
            }
        }
    }
}