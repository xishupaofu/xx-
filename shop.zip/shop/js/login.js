//获取操作对象
var inps = document.querySelectorAll('form input')
var btn = document.querySelector('form button')
console.log('1')

// 定义变量
var u1 = false
var p1 = false
// 验证输入格式
inps[0].onblur = function () {
    var val = this.value
    //正则表达式
    var reg = /^[\u4e00-\u9fa5]{2,5}$/
    if (reg.test(val)) {
        var u1 = true
    } else {
        inps[0].value = '请重新输入用户名'
    }
}
inps[1].onblur = function () {
    var val = this.value
    //正则表达式
    var reg = /^\w{6,16}$/
    if (reg.test(val)) {
        var p1 = true
    } else {
        inps[1].value = '请重新输入密码'
    }
}

// 集中焦点后
inps[0].onfocus = function () {
        inps[0].value = ''
    
}
inps[1].onfocus = function () {
    inps[1].value = ''
}

//给按钮绑定点击事件
btn.onclick = function () {
    //获取输入框中的内容
    var u1 = inps[0].value
    var p1 = inps[1].value
    //调用ajax方法，验证该账号和密码是否正确
    ajax1({
        url: '../php/login.php',
        data: `user=${u1}&pass=${p1}`,
        type: 'post',
        success: function (dt) {
            //判断当前结果是否为1
            if (dt == 1) {
                //保存登录成功的账号
                setCookie('name1', u1)
                //获取地址栏中的参数信息
                var search = location.search
                if (search) {
                    //获取参数信息
                    var url2 = search.split('?url=')[1]
                    //跳转到指定地址
                    location = url2
                } else {
                    //跳转到指定页面
                    location = "./list.html"
                }
            } else {
                alert("账号或密码有误")
                // location.reload()
            }
        }
    })
}