//获取操作对象
var inps = document.querySelectorAll('input')
var btn = document.querySelector('[type="button"]')
var spans = document.querySelectorAll('form span')
//创建变量，判断输入框的内容是否合法
var u1 = false
var p1 = false
var e1 = false
//给输入框绑定失去焦点事件
inps[0].onblur = function () {
    //获取输入框中的内容
    var val = this.value
    //正则表达式
    var reg = /^[\u4e00-\u9fa5]{2,5}$/
    if (reg.test(val)) {
        ajax1({
            url: '../php/zhuce2.php',
            data: `username=${val}`,
            success: function (dt) {
                //判断返回值是否为1
                if (dt == 1) {
                    spans[0].innerHTML = "该用户以存在"
                    u1 = false
                } else {
                    spans[0].innerHTML = "√"
                    u1 = true
                }
            }
        })
    } else {
        spans[0].innerHTML = "格式有误"
        u1 = false
    }
}
//密码验证
inps[1].onblur = function () {
    var val = this.value
    var reg = /^\w{6,16}$/
    if (reg.test(val)) {
        spans[1].innerHTML = "√"
        p1 = true
    } else {
        spans[1].innerHTML = "密码有误"
        p1 = false
    }
}
//邮箱验证
inps[3].onblur = function () {
    var val = this.value
    var reg = /^[1-9]\d{5,9}@qq\.com$/
    if (reg.test(val)) {
        spans[3].innerHTML = "√"
        e1 = true
    } else {
        spans[3].innerHTML = "邮箱有误"
        e1 = false
    }
}
//给选中框绑定点击事件
inps[4].onclick = function () {
    //判断选中框是否被选中
    if (this.checked) {
        //取消提交按钮的禁用
        btn.disabled = false
    } else {
        btn.disabled = true
    }
}

//给按钮绑定点击事件
btn.onclick = function () {
    //获取输入框中的内容
    var u2 = inps[0].value
    var p2 = inps[1].value
    var tel = inps[2].value
    var eam = inps[3].value
    //判断是否所有输入框的验证通过
    if (u1 && p1 && e1) {
        //使用ajax发送请求
        ajax1({
            url: '../php/zhuce.php',
            data: `user=${u2}&pass=${p2}&phone=${tel}&email=${eam}`,
            success: function (dt) {
                //判断返回值是否为1
                if (dt == 1) {
                    alert("注册成功")
                    location = "login.html"
                } else {
                    alert("注册失败")
                    location = ''
                }
            }
        })
    }
}