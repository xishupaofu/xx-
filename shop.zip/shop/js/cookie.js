//添加cookie
function setCookie(key, value, time1 = 0) {
    //判断time1是否为0
    if (time1) {
        //获取当前时间
        var dt1 = new Date()
        //设置保存时间
        var t1 = dt1 - 8 * 3600 * 1000 + time1 * 1000
        //设置保存内容
        document.cookie = `${key}=${value};expires=${new Date(t1)}`
    } else {
        document.cookie = `${key}=${value}`
    }
}

//获取cookie
function getCookie(key) {
    //获取所有cookie
    let c1 = document.cookie
    //分割当前获取到的字符串
    var ar1 = c1.split('; ')
    //遍历数组
    for(var i=0;i<ar1.length;i++){
        //分割当前遍历出来的字符串
        var ar2=ar1[i].split('=')
        //判断当前键名是否等于传入的键名
        if(ar2[0]==key){
            return ar2[1]
        }
    }
}
//删除cookie
function deleteCookie(key){
    setCookie(key,'',-1)
}